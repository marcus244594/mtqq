import { Match } from '../types';

export const matches: Match[] = [
  {
    id: 1,
    homeTeam: 'Manchester United',
    awayTeam: 'Liverpool',
    homeScore: 2,
    awayScore: 1,
    time: 'FT',
    league: 'Premier League',
    date: '2025-05-01',
    probability: 85
  },
  {
    id: 2,
    homeTeam: 'Barcelona',
    awayTeam: 'Real Madrid',
    homeScore: 3,
    awayScore: 2,
    time: 'FT',
    league: 'La Liga',
    date: '2025-05-01',
    probability: 92
  },
  {
    id: 3,
    homeTeam: 'Bayern Munich',
    awayTeam: 'Borussia Dortmund',
    homeScore: 2,
    awayScore: 2,
    time: 'FT',
    league: 'Bundesliga',
    date: '2025-05-01',
    probability: 88
  },
  {
    id: 4,
    homeTeam: 'PSG',
    awayTeam: 'Marseille',
    homeScore: 2,
    awayScore: 0,
    time: 'FT',
    league: 'Ligue 1',
    date: '2025-05-01',
    probability: 78
  },
  {
    id: 5,
    homeTeam: 'AC Milan',
    awayTeam: 'Inter Milan',
    homeScore: 1,
    awayScore: 1,
    time: 'FT',
    league: 'Serie A',
    date: '2025-05-01',
    probability: 82
  },
  {
    id: 6,
    homeTeam: 'Ajax',
    awayTeam: 'PSV',
    homeScore: 3,
    awayScore: 0,
    time: 'FT',
    league: 'Eredivisie',
    date: '2025-05-01',
    probability: 75
  },
  {
    id: 7,
    homeTeam: 'Sporting CP',
    awayTeam: 'Benfica',
    homeScore: 1,
    awayScore: 2,
    time: 'FT',
    league: 'Primeira Liga',
    date: '2025-05-01',
    probability: 80
  },
  {
    id: 8,
    homeTeam: 'Celtic',
    awayTeam: 'Rangers',
    homeScore: 3,
    awayScore: 1,
    time: 'FT',
    league: 'Scottish Premiership',
    date: '2025-05-01',
    probability: 85
  },
  {
    id: 9,
    homeTeam: 'River Plate',
    awayTeam: 'Boca Juniors',
    homeScore: 2,
    awayScore: 2,
    time: 'FT',
    league: 'Primera División',
    date: '2025-05-01',
    probability: 90
  }
];