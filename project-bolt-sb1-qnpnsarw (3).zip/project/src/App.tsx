import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import MatchesGrid from './components/MatchesGrid';
import SportsbookSection from './components/SportsbookSection';
import { matches } from './data/mockData';

// Filter to only include matches with more than 1.5 goals
const filteredMatches = matches.filter(
  match => (match.homeScore + match.awayScore) > 1.5
);

function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2 text-center">Soccer Games Over 1.5 Goals</h2>
          <p className="text-gray-600 text-center max-w-2xl mx-auto">
            Track the latest matches that went over 1.5 goals. Updated in real-time with reliable statistics.
          </p>
        </div>
        
        <section className="mb-12">
          <div className="mb-6 flex justify-between items-center">
            <h3 className="text-xl font-bold">Today's Matches</h3>
            <div className="text-sm bg-black text-white px-3 py-1 rounded-full">
              {filteredMatches.length} Matches
            </div>
          </div>
          
          <MatchesGrid matches={filteredMatches} />
        </section>
        
        <SportsbookSection />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;