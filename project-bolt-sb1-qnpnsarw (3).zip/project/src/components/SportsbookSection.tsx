import React from 'react';

const sportsbooks = [
  {
    id: 1,
    name: 'BetMGM',
    logo: 'https://images.pexels.com/photos/5816293/pexels-photo-5816293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    url: 'https://sports.betmgm.com/en/sports',
    bonus: 'Up to $1,000 First Bet Offer'
  },
  {
    id: 2,
    name: 'FanDuel',
    logo: 'https://images.pexels.com/photos/5816293/pexels-photo-5816293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    url: 'https://sportsbook.fanduel.com/',
    bonus: '$150 in Bonus Bets'
  },
  {
    id: 3,
    name: 'DraftKings',
    logo: 'https://images.pexels.com/photos/5816293/pexels-photo-5816293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    url: 'https://sportsbook.draftkings.com/',
    bonus: 'Up to $1,000 + $50 Bonus Bet'
  },
  {
    id: 4,
    name: 'Caesars',
    logo: 'https://images.pexels.com/photos/5816293/pexels-photo-5816293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    url: 'https://www.caesars.com/sportsbook-and-casino',
    bonus: 'Up to $1,000 First Bet'
  }
];

const SportsbookSection: React.FC = () => {
  return (
    <section className="py-8">
      <h2 className="text-2xl font-bold mb-6 text-center">Arkansas Legal Sportsbooks</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {sportsbooks.map((book) => (
          <a 
            key={book.id}
            href={book.url}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white text-black rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="h-32 bg-gray-200 flex items-center justify-center">
              <div className="bg-black text-white font-bold text-xl p-4 rounded">
                {book.name}
              </div>
            </div>
            <div className="p-4">
              <p className="font-medium mb-2">{book.name}</p>
              <p className="text-sm text-gray-700 mb-2">{book.bonus}</p>
              <button className="w-full bg-black text-white py-2 rounded font-medium hover:bg-gray-800 transition-colors">
                Bet Now
              </button>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
};

export default SportsbookSection;