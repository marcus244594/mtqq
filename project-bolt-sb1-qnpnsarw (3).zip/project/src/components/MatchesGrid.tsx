import React from 'react';
import MatchCard from './MatchCard';
import { Match } from '../types';

interface MatchesGridProps {
  matches: Match[];
}

const MatchesGrid: React.FC<MatchesGridProps> = ({ matches }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
      {matches.map((match) => (
        <MatchCard key={match.id} match={match} />
      ))}
    </div>
  );
};

export default MatchesGrid;